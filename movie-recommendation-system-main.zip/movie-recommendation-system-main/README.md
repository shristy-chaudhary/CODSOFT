# movie-recommendation-system
top 10 similar movies recommended as per the movie selected by user
